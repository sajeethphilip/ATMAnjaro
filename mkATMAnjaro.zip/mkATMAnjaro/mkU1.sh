export Home="/mnt"
#/home/nsp/Downloads
echo "Please specify which version to install (tiny, Gis,Astro):"
read vrname
export "$vrname"
#sudo pacman -Syu
sudo pacman -Sy  grub2 \
    binutils \
    debootstrap \
    squashfs-tools \
    xorriso \
    grub-pc-bin \
    grub-efi-amd64-bin \
    mtools \
    plymouth-themes
umount  $Home/atmanjaro/chroot/dev
umount  $Home/atmanjaro/chroot/run
rm -r $Home/atmanjaro
mkdir -p $Home/atmanjaro/chroot/dev
mkdir -p $Home/atmanjaro/chroot/run
mkdir -p $Home/atmanjaro/chroot/etc/
cp /etc/resolve.conf  $Home/atmanjaro/chroot/etc/

sudo debootstrap \
   --arch=amd64 \
   --variant=minbase \
   focal \
   $Home/atmanjaro/chroot \
   http://us.archive.ubuntu.com/ubuntu/
rm -r  $Home/atmanjaro/chroot/debootstrap
mount --bind /dev $Home/atmanjaro/chroot/dev
mount --bind /run $Home/atmanjaro/chroot/run

if [ "$vrname" != "tiny" ]; then
if [ "$vrname" == "Astro" ]; then
cp -r IRAF/* $Home/atmanjaro/chroot/
fi
cp -r Update_enterprice $Home/atmanjaro/chroot/Update
cat "$vrname.txt" >> $Home/atmanjaro/chroot/Update/packages_list.txt
cp mkU2.sh  $Home/atmanjaro/chroot/
else
cp -r Update $Home/atmanjaro/chroot/
cp mkU20.sh  $Home/atmanjaro/chroot/mkU2.sh
fi

mkdir -p $Home/atmanjaro/chroot/usr/share/plymouth/themes/ubuntu-logo/
cp atmabuntu.png $Home/atmanjaro/chroot/usr/share/plymouth/themes/ubuntu-logo/
cp atmabuntu.png $Home/atmanjaro/chroot/usr/share/plymouth/themes/ubuntu-logo/atmabuntu16.png
cp Plymouth/default.plymouth $Home/atmanjaro/chroot/usr/share/plymouth/
mkdir -p $Home/atmanjaro/chroot/boot/grub2/images
cp Plymouth/atmabuntu.jpg $Home/atmanjaro/chroot/boot/grub2/images/ # <-- provide the location of your image
mkdir -p $Home/atmanjaro/chroot/etc/default
cp grub $Home/atmanjaro/chroot/etc/default/grub.1
RED='\033[33;5m'
NC='\033[0m'
 
echo -e "${RED}Please run mkU2.sh at the command prompt${NC}"

sudo chroot  $Home/atmanjaro/chroot  


