#!/bin/sh
HOME='/atma_mnt'
pacman -Sy manjaro-tools
pacman -Sy manjaro-tools-iso git
rm -r $HOME/iso-profiles
git clone https://gitlab.manjaro.org/profiles-and-settings/iso-profiles.git $HOME/iso-profiles

mkdir -p $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/
cp -r etc/* $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/
mkdir -p $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/mc
mkdir -p $HOME/iso-profiles/manjaro/xfce/desktop-overlay/var/lib/pacman
cp exitcwd $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/mc
cp /etc/bash.bashrc  $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/
xz=`cat /etc/bash.bashrc | grep "flatpak" `
if  [ -z "$xz" ]; then
    echo "alias mc=' . /etc/mc/exitcwd' " >> $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
    echo "if [ \"\$EUID\" -ne 0 ];then" >> $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
    echo "flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo --user">> $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
    echo "else">> $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
    echo "chmod 1777 /dev/shm;">> $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
    echo " fi">> $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
    echo 'echo "          You can use flatpak install --user <file>"'>> $HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
    echo 'echo "to install packages to your folder without having root permissions"'>>$HOME/iso-profiles/manjaro/xfce/desktop-overlay/etc/bash.bashrc
fi
cp -r usr $HOME/iso-profiles/manjaro/xfce/desktop-overlay/
echo "`pwd`"
cp ./manjaro-tools.conf /etc/manjaro-tools/
#for i in `cat Science.pkgs`;do
#pacman -Sy $i --needed --noconfirm -r $HOME/iso-profiles/manjaro/xfce/desktop-overlay
#done
cp Packages-Desktop >$HOME/iso-profiles/manjaro/xfce/Packages-Desktop
cat Science.pkgs >>$HOME/iso-profiles/manjaro/xfce/Packages-Desktop
cp -Lr $HOME/iso-profiles/manjaro/xfce /usr/share/manjaro-tools/
ln -sf /usr/share/manjaro-tools/xfce /usr/share/manjaro-tools/iso-profiles/xfce
cd /usr/share/manjaro-tools
#mv /mnt/manjaro-tools /mnt/manjaro-tools-old
#mv  /var/lib/manjaro-tools /mnt/
#ln -sf /mnt/majaro-tools /var/lib/manjaro-tools
cp manjaro-tools.conf /etc/manjaro-tools/
buildiso -f -p xfce -b stable
#buildiso -p xfce
rm -r /atma_mnt/lib/manjaro-tools
